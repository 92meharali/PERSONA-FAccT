# PERSONA: FAccT 2027 Overleaf manuscript

## Compile

Upload this ZIP as an Overleaf project, choose `main.tex`, and use pdfLaTeX.
Recompile from scratch if an interrupted build leaves unresolved citations.
The package includes 24 cited references, generated result tables, vector figures,
and the unmodified ACM v2.19 class and bibliography style. No shell escape or
external data download is needed for typesetting.

## Current revision: 27 October 2026

The manuscript presents the PERSONA corpus, original annotation, review-allocation
audit, and contextual-reviewworthiness follow-up as stages of one study. It does
not frame the work as an extension of a concurrently reviewed companion paper.
Original sources, numerical results, and the actual exploration history remain
unchanged. The follow-up adds judgments on existing responses, not a new corpus.

This revision addresses the annotated PDF and review checklist:

- Clearer contributions, terminology and decision flow.
- Broad-D versus contextual-reviewworthiness distinction and rubric alignment.
- Recorded imported HumT score provenance and exact text-mismatch counts.
- Original specified family versus additional exploratory analyses.
- Capability assumptions, generation role and researcher involvement.
- Review slots versus reviewer time; uncertainty versus point ordering.
- Figure/caption clarity and appendix floats kept within their sections.
- Workload in Results; the unevaluated reporting card in Discussion.

No new scores, annotations, semantic-judge experiment, independently sourced
marker list or participant study is claimed. Historical scorer calls and
pre-inspection marker-list selection are not authenticated. The author checklist
retains these evidence boundaries.

## Format and verification

The official author guide, checked 27 October 2026, permits 14 single-column
content pages including figures/tables, one additional endmatter-only page, and
unlimited references and appendices in the same PDF:
https://facctconference.org/2027/authorguide.html

The local pdfLaTeX build has **14 content pages, 1 endmatter page, 2 reference
pages and 19 appendix pages: 36 total**. Appendix sections now start on separate
pages to prevent floats appearing under the wrong heading. Total PDF length is
not the main-content limit. The saved source also compiles in the desktop editor.
No fonts or margins were reduced. Check `package_manifest.json` for hashes and
the layout report, and recheck pagination after any Overleaf edits.

The bibliography and numerical tables are unchanged in content. Updated table
captions are checked against the prior package's tabular bodies. The revised
summary figure is regenerated from the same analytical outputs. No undefined
citations/references or overfull boxes remain in the local pdfLaTeX log. The class
still emits its generic ACM-reference-block and CCS notices for this review setup.

## Contents and boundaries

- `main.tex`: manuscript, ethics/AI-use endmatter and appendices.
- `references.bib`: 24 existing cited records; no added references in this revision.
- `tables/`, `figures/`: generated presentation assets, not source judgments.
- `acmart.cls`, `ACM-Reference-Format.bst`, `template-source/`: unchanged template.
- `AUTHOR_CHECKLIST.md`: author checks, not part of the compiled paper.
- `package_manifest.json`: package checksums and verification status.

The package excludes raw participant records, identifying institutional documents,
source response datasets and prospective human-study materials. It is a portable
typesetting package, not a standalone full-data reproducibility release. The
prepared semantic-judge runner and exploratory in-chat scoring are outside the
paper; neither is represented as an independent semantic comparator.
