# Before Submission

Current revision: 27 October 2026. This is a self-contained study report, not a
claim that new experiments were completed during manuscript revision.

- **Layout:** verify the exact Overleaf rendering. The local build has 14 content,
  one endmatter, two reference and 19 appendix pages. The class and margins are
  unchanged. Appendices are excluded from the content limit, but the main text
  must remain self-contained.
- **Score provenance:** recorded imported HumT scores are not authenticated
  historical invocations. Of 830 transfer-domain pairs, 59 differ in full text
  and 47 in their recorded scoring prefix. Mental-health scoring-input strings
  are unavailable. Existing sensitivity checks do not close this gap.
- **Marker provenance:** the list is recorded in the 2 October specification,
  after prior data exploration. Exact word-selection chronology is unverified.
  Do not describe this as an independently sourced or outcome-blind dictionary.
- **Criterion validity:** broad D includes ordinary sympathy. Author/intern
  framework familiarity and lexical overlap can influence comparative results.
  OA comes from a separate group, but is not independent ground truth for harm.
- **Follow-up:** two complete streams cover 660 responses each; the third covers
  14 disagreements only. There are 19 resolved contextual-reviewworthiness
  cases in 13 prompts. The HumT-marker paired interval includes zero. Capability
  instruction versions differ; do not claim same-instruction reliability.
- **Annotation and ethics:** retain the available institutional, recruitment,
  consent and payment records privately. Match final methods to those records;
  do not transfer original-team payment facts to new assessors or invent missing
  individual qualifications. Intern withdrawal protections are author-confirmed.
- **Exploration:** the primary family was specified after prior exploration.
  Later computational and follow-up analyses remain exploratory, not retrospective
  preregistration. No equivalence or universal HumT redundancy is established.
- **Comparator scope:** fixed lexical rules and one untuned trained lexical
  screen are evaluated. No independent semantic/LLM-judge baseline, new externally
  sourced dictionary or practitioner workflow evaluation has been completed.
- **Capacity:** full-batch 132/83/83 slots differ from held-out 130/80/80 slots.
  Do not compare across these families as a matched-capacity policy contrast.
  Slots do not measure reading time or labor savings.
- **Reporting card:** an unevaluated proposal, not validated contestation,
  organizational adoption or safety certification. Non-selection is not clearance.
- **AI disclosure:** substantial Codex assistance is disclosed. Report actual
  underlying model/version information from preparation logs if available; none
  is invented here. Authors must approve claims, references and submitted text.
- **Anonymity and release:** omit identifying links, consent records, institutional
  letters and sensitive case text from review materials. This ZIP is a typesetting
  package, not a complete anonymous data artifact. Check source redistribution
  rights and the actual submission metadata separately.
- **References:** 24 existing references retained. Organizational reports are
  labeled as such; HealthBench is cited as a preprint. No new citations were added.

Official format and submission instructions:
https://facctconference.org/2027/authorguide.html
https://facctconference.org/2027/cfp.html

Nothing in this package sends a submission or message, changes participant
records, or authorizes new API calls or recruitment.
